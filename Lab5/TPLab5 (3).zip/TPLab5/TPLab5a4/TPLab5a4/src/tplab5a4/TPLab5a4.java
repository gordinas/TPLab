/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tplab5a4;
import java.util.Scanner;
/**
 *
 * @author gordi
 */
public class TPLab5a4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          Scanner in = new Scanner(System.in);
          int C[];
          boolean stop=false;
          C = new int[129];
        String[]substr;
        do{System.out.println("Введите строку чисел разграниченных запятыми");
        String s= in.next();
        substr=s.split(",");
        int sumnegative=0;
        int npositive=0;
        
            try
             { 
                 for(int i=0;i<substr.length;i++){
                 C[i]= Integer.parseInt(substr[i]);
                 if (C[i]>0){npositive++;}
                 else{ sumnegative+=C[i];}}
                 System.out.println("Сумма отрицательных чисел: "+ sumnegative);
                 System.out.println("Количество положительных чисел: "+ npositive);
                for(int i=0;i<substr.length;i++){
                System.out.println("C["+i+"]= "+C[i]);
                stop= true;} 
         
         
}
catch(NumberFormatException e)
{
    
}
   }while(! stop);
              
        // TODO code application logic here
    }
    
}
