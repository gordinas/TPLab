 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tplab5a1c;
import java.util.Scanner;
/**
 *
 * @author gordi
 */
public class TPLab5a1c {

    /**
     * @param args the command line arguments
     */
     public static double readDoubleFromConsol (char a) {
        Scanner in = new Scanner(System.in);
         double t =0;
          boolean stop= false;
         while(!stop){
             System.out.println("Введите "+a+":");
             try
             {String ts= in.next(); 
         t= Double.parseDouble(ts);
         stop=true;
         
}
catch(NumberFormatException e)
{

}

         }

return t;
     }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a=readDoubleFromConsol('a');
       double b=readDoubleFromConsol('b');
       double c=readDoubleFromConsol('c');
       double d=readDoubleFromConsol('d');
       double e=readDoubleFromConsol('e');
       double f=readDoubleFromConsol('f');
       if(!((a==d)||(d==e)||(c==f))){double x=(f+c*e/b)/(d-a*e/b);
        double y= (c-a*x)/b;
         if((x!=Double.POSITIVE_INFINITY)&&(y!=Double.POSITIVE_INFINITY)&&(x!=Double.NEGATIVE_INFINITY)&&(y!=Double.NEGATIVE_INFINITY)&&(x!=Double.NaN)&&(y!=Double.NaN)){
         System.out.println("x="+x);
         System.out.println("y="+y);}
            else{ System.out.println("Нет решений");}}
       else{System.out.println("Система уравнений имеет бесконечное множество решений");}
       
         } 
 
        // TODO code application logic here
         
    }
