/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tplab5a2;
import java.util.Scanner;
/**
 *
 * @author gordi
 */
public class TPLab5a2 {
 public static double readDoubleFromConsol () {
        Scanner in = new Scanner(System.in);
         double t =0;
          boolean stop= false;
         while(!stop){
             System.out.println("Введите параметр");
             try
             {String ts= in.next(); 
         t= Double.parseDouble(ts);
         stop=true;
         
}
catch(NumberFormatException e)
{

}

         }

return t;
     }
 public static int readIntFromConsol () {
        Scanner in = new Scanner(System.in);
         int t =0;
          boolean stop= false;
         while(!stop){
             System.out.println("Введите номер параметра");
             try
             {String ts= in.next(); 
         t=Integer.parseInt(ts);
         stop=true;
         
}
catch(NumberFormatException e)
{

}

         }

return t;
     }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int N=0;
        do{ N = readIntFromConsol ();}
        while(!((N>0) && (N<5)));  
            double x =0;
            do{
            x = readDoubleFromConsol ();
            }while(!(x>0));
           double Y1=0;
                        double Y2=0;
                        double Y3=0;
                        double Y4=0;
                    
            switch (N)
            {
                case 1:
                    Y1=x;
                    Y2=Math.sqrt(3) / 6 * x;
                    Y3=2*Y2;
                    Y4= x * x * Math.sqrt(3) / 4;
                    break;   
                case 2:
                        Y1 = x * 6 / Math.sqrt(3);
                        Y2 = x;
                        Y3 = 2*x;
                        Y4=x * x * Math.sqrt(3) / 4;
                    break;
                case 3:
                        Y1 = x * 3 / Math.sqrt(3);
                        Y2 = x / 2;
                        Y3 = x;
                        Y4 = Y1 * Y1 * Math.sqrt(3) / 4;;
                    break;
                case 4:
                        Y1= Math.sqrt(4 * x / Math.sqrt(3));
                        Y2=Math.sqrt(3) / 6 * x;
                        Y3=2 * Y2;
                        Y4=x;
                    break;
                default:

                    break;
            }
            System.out.println("сторона: "+Y1);
            System.out.println("радиус вписанной окружности: "+Y2);
            System.out.println("радиус описанной окружности: "+Y3);
            System.out.println("площадь треугольника: "+Y4);
            System.exit(0);
        // TODO code application logic here
    }
    
}
