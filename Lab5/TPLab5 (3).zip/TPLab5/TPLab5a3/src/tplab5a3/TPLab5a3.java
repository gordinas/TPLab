/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tplab5a3;
import java.util.Scanner;
/**
 *
 * @author gordi
 */
public class TPLab5a3 {
    
public static double readDoubleFromConsol (int i) {
        Scanner in = new Scanner(System.in);
         double t =0;
          boolean stop= false;
         while(!stop){
             System.out.println("Введите C["+i+"]");
             try
             {String ts= in.next(); 
         t= Double.parseDouble(ts);
         stop=true;
         
}
catch(NumberFormatException e)
{

}

         }

return t;
     }
public static int readIntFromConsol () {
        Scanner in = new Scanner(System.in);
         int t =0;
          boolean stop= false;
         while(!stop){
             System.out.println("Введите размерность вектора");
             try
             {String ts= in.next(); 
         t=Integer.parseInt(ts);
         stop=true;
         
}
catch(NumberFormatException e)
{

}

         }

return t;
     }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          double C[];
          C = new double[9];
          double C1[];
          C1 = new double[9];
          int N=0;
              do{N =readIntFromConsol () ;}
                 while((N>9)||!(N>0));
              double sum =0;
          for (int i=0;i<N;i++){
           C[i]=  readDoubleFromConsol (i); 
           sum+=C[i];
          }
          double sr=sum/N;
          for (int i=0;i<N;i++){
           C1[i]= C[i]-sr; 
           System.out.println("C1["+i+"]="+C1[i]);
          }
        // TODO code application logic here
    }
    
}
