﻿using System;
using System.Collections.Generic;
class Example
{
    public static void Main()
    {
        Stack<string> numbers = new Stack<string>();
        numbers.Push("6"); numbers.Push("7"); numbers.Push("8"); numbers.Push("9"); numbers.Push("10"); numbers.Push("Валет"); numbers.Push("Дама"); numbers.Push("Король"); numbers.Push("Туз");
        // Стек можно перебрать без обращения к его содержимому.
        foreach (string number in numbers)
        { Console.WriteLine(number); }
        Console.WriteLine("\nВзять верхний элемент {0}", numbers.Pop());
        Console.WriteLine("Получить верхний элемент без его удаления: {0}",
            numbers.Peek());
        Console.WriteLine("Взять верхний элемент {0}", numbers.Pop());

        // Создать копию стека, используя метод ToArray и конструктор, который принимает массив строк
        Stack<string> stack2 = new Stack<string>(numbers.ToArray());
        Console.WriteLine("\nСодержимое копии:");
        foreach (string number in stack2)
        {
            Console.WriteLine(number);
        }
        Console.WriteLine("\nstack2.Содержит(\"Туз\") = {0}",
            stack2.Contains("Туз"));
        Console.WriteLine("\nОчистка stack2");
        stack2.Clear();
        Console.WriteLine("\nЧисло элементов stack2 = {0}", stack2.Count);
    }
}
