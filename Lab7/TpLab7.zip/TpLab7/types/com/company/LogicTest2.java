package com.company;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static com.company.Cartoon.TypeOfCartoon.drawn;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class LogicTest2 {


    @BeforeAll
    public static void ArrayTestBefore() {


        Main.objs[0] = new Fiction_Film("Сказ про то как царь Петр арапа женил", 1000, "Митта", 300);
        Main.objs[1] = new Fiction_Film("Мертвые души", 2000,"Швейцер" , 1000);
        Main.objs[2] = new Cartoon("Мульт-личности",500 ,drawn,30);
        Main.objs[3] = new Cartoon("Смешарики", 100, drawn, 24);


    }
    @Test
    public  void ArrayTestAfter() {
        Logic.Cost();
        assertEquals(Main.CostResult[0],300000);
        assertEquals(Main.CostResult[1],2000000);
        assertEquals(Main.CostResult[2],15000);
        assertEquals(Main.CostResult[3],2400);
    }
}
