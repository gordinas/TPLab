package com.company;

public class Logic {
    public static void Cost()
    {

        for (int i = 0; i < 4; i++)
        {
             Cost m = (Cost) Main.objs[i];
            Main.CostResult[i]=m.cost();
        }

    }
    public static int  getCost(int i){
        return Main.CostResult[i];
    }
}
