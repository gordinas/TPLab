package com.company;

public class My {
    public static int getFactorialPrice(int num) throws MyException{

        int result=1;
        if(num<0) throw new MyException("Введенное число не должно быть отрицательным", num);

        return num;
    }
    public static int getQuantifyOfPerson(int num) throws MyException{

        int result=1;
        if(num<1) throw new MyException("Введенное число должно быть больше нуля", num);

        return num;
    }
    public static int getQuantifyOfArts(int num) throws MyException{

        int result=1;
        if(num<1) throw new MyException("Введенное число должно быть больше нуля", num);

        return num;
    }
    public static int gettype(int num) throws MyException{

        int result=1;
        if((num<1)||(num>3)) throw new MyException("Введенное число должно быть от 1  до 3", num);

        return num;
    }
}
