package com.company;
import java.util.Scanner;

import static com.company.Cartoon.TypeOfCartoon.*;

public class Main {

private static boolean stop;
    private static boolean stoprecord;
private static Integer t ;
public static int price;
public static int i =0;
    enum  TypeOfMovie{Fiction_Film("игровой фильм"),Cartoon("Мультфильм");
        public String getRuName() {
            return ruName;
        }

        private String ruName;
        TypeOfMovie(String theRuName){
            this.ruName = theRuName;
        }};
private static boolean recording;
public static  String namemovie;
public static  String producer;
 public static   int QuantifyOfPerson;
    private static int m;
    public static boolean was=false;
    public static Cartoon.TypeOfCartoon c;
    public static int QuantifyOfArts;
    public static int[] CostResult= new int[4];
    public static Movie[] objs = new Movie[4];
    public static void main(String[] args) {
        try {
            Scanner in = new Scanner(System.in);
            // начало взаимодействия с пользователем
            addObj();
            // конец взаимодействия с пользователем
            //начало логики
            Logic.Cost();
            //конец логики
            // начало взаимодействия с пользователем
            printObg();
//конец взаимодействия с пользователем
        }

        catch(NumberFormatException e)
        {
            System.out.println("Некорректный тип данных");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch(MyException ex){

            System.out.println(ex.getMessage());
            System.out.println(ex.getNumber());
        } catch (Exception e) {
            System.out.println("Введены некорркетные данные");
        }

    }
    public static void addObj() throws MyException {System.out.println();
        addF();
        addC();


    }
    public static void addF() throws MyException {
        Scanner in = new Scanner(System.in);
for (i=0;i<2;i++)
{ boolean correcting= true;
        System.out.println("Введите название игрового фильма");
        namemovie= in.next();
        System.out.println("Введите фамилию режиссера");
        producer= in.next();
        System.out.println("Введите стоимость одного работника съемочной группы");
            price=My.getFactorialPrice(Integer.parseInt(in.next()));
        System.out.println("Введите  число работников съемочной группы");
        QuantifyOfPerson= My.getQuantifyOfPerson(Integer.parseInt(in.next()));
            objs[i] = new Fiction_Film(namemovie, price, producer, QuantifyOfPerson);
}



    }
    public static void addC() throws MyException {
        for(i=0;i<2;i++) {
            Scanner in= new Scanner(System.in);
            boolean correcting= true;
                int type;
                System.out.println("Если фильм рисованный нажмите 1");
                System.out.println("Если фильм кукольный нажмите 2");
                System.out.println("Если фильм пластилиновый нажмите 3");
                type= My.gettype(Integer.parseInt(in.next()));   ;
                switch(type){
                    case 1:
                        c=drawn;
                        break;
                    case 2:
                        c=upped;
                        break;
                    case 3:
                        c=plastilin;
                        break;

                }
                System.out.println("Введите название мультфильма");
                namemovie= in.next();
                System.out.println("Введите стомость одного работника съемочной группы");
                price = My.getFactorialPrice(Integer.parseInt(in.next()));;
                System.out.println("Введите  число работников съемочной группы");
                QuantifyOfArts = My.getQuantifyOfArts(Integer.parseInt(in.next()));;
                    objs[i+2] = new Cartoon(namemovie, price, c, QuantifyOfPerson);
        }

    }






    public static void printObg()
    {

        for (int i = 0; i < 4; i++) {
            System.out.println(   "Стоимость фильма =     " +CostResult[i]);
        }
    }





}