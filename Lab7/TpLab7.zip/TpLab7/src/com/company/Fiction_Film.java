package com.company;

public class Fiction_Film  extends Movie {
    private  String producer;
    private  int QuantifyOfPerson;

    public Fiction_Film(String namemovie, int price,String producer,int QuantifyOfPerson) {
        super (namemovie, price);
        this.setproducer(producer);
        this.setQuantityOfPerson(QuantifyOfPerson);
    }

    public  int getQuantifyOfPerson(){
       return QuantifyOfPerson;
    }
    public  String getproducer(){
       return producer;
    }

    public void setQuantityOfPerson(int QuantifyOfPerson){
        this.QuantifyOfPerson=QuantifyOfPerson;
    }
    public void setproducer(String producer){
        this.producer=producer;
    }

    public String info()
    {
        return  "Игровой фильм     "  + " ;      название :   " + super.getnamemovie() + ";     фамилия режиссера =    " + getproducer()+ ";     стоимость одного работника = " + super.getprice()+"     число работников съемочной группы:    " + getQuantifyOfPerson();
    }
    public  int cost(){
        return getQuantifyOfPerson()*getprice();
    }

    }



