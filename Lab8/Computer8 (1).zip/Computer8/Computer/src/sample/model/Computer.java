package sample.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

// тут написано что создай свойство @class и пропиши в нем имя класса
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include= JsonTypeInfo.As.PROPERTY, property="@class")
@JsonIgnoreProperties({"description"}) // указали что свойство description нужно игнорировать

public  class Computer {


    public Computer() {

    }



    public String nameComputer;
    public Integer id = null;


    public String getnameComputer(){return nameComputer;}
    public void setnameComputer(String nameComputer) {this.nameComputer = nameComputer;}

    public Computer(String nameComputer) {this.setnameComputer(nameComputer);}



    public String getDescription() {
        return "";
    }
    @Override
    public String toString() {
        return String.format("%s км", this.getnameComputer());
    }
}