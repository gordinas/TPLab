package sample.GUI;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.InputMethodTextRun;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import sample.Main;
import sample.model.*;

import javax.swing.*;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class ComputerController implements Initializable {


    public MovieModel MovieObjModel;
    private Integer id = null;
    public ChoiceBox cmbTypeOfCartoon;
    public ChoiceBox cmbMovieObjType;
    public TextField nameMovieText;

    public VBox Fiction_FilmPane;
    public VBox CartoonPane;
    public MovieModel Computer;
    public TextField QuantifyOfPersonValue;
    public TextField QuantifyOfArtsValue;
    public TextField producerValue;
    final String Movie_Fiction_Film = "Игровой фильм";
    final String  Movie_Cartoon = "Мультфильм";
    public TextField priceValue;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        cmbMovieObjType.setItems(FXCollections.observableArrayList(
                Movie_Fiction_Film,
                Movie_Cartoon
        ));
        cmbMovieObjType.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            updatePanes((String) newValue);
        });
        cmbTypeOfCartoon.getItems().setAll(
               Cartoon.TypeOfCartoon.Рисованный,
                Cartoon.TypeOfCartoon.Кукольный,
                Cartoon.TypeOfCartoon.Пластилиновый
        );


        cmbTypeOfCartoon.setConverter(new StringConverter< Cartoon.TypeOfCartoon>() {
            @Override
            public String toString(Cartoon.TypeOfCartoon object) {
                switch (object) {
                    case Рисованный: return "Рисованный" ;
                    case Кукольный: return "Кукольный" ;
                    case Пластилиновый: return "Пластилиновый";
                }
                return null;
            }
            @Override
            public Cartoon.TypeOfCartoon fromString(String string) {
                return null;
            }
        });

    }

    public void updatePanes(String value) {
        this.Fiction_FilmPane.setVisible(value.equals(Movie_Fiction_Film));
        this.Fiction_FilmPane.setManaged(value.equals(Movie_Fiction_Film));
        this.CartoonPane.setVisible(value.equals(Movie_Cartoon));
        this.CartoonPane.setManaged(value.equals(Movie_Cartoon));
    }

    public void setMovie(Movie Movie) {
        this.cmbMovieObjType.setDisable(Movie != null);
        this.id = Movie != null ? Movie.id : null;
        if (Movie != null) {
            this.nameMovieText.setText(String.valueOf(Movie.getnameMovie ()));
            this.priceValue.setText(String.valueOf(Movie.getPrice()));
            if (Movie instanceof Fiction_Film) {
                this.cmbMovieObjType.setValue(Movie_Fiction_Film);
                this.QuantifyOfPersonValue.setText(String.valueOf(((Fiction_Film) Movie).QuantifyOfPerson));
                this.producerValue.setText(String.valueOf(((Fiction_Film) Movie).producer));
            } else {
                this.cmbMovieObjType.setValue(Movie_Cartoon);
                this.cmbTypeOfCartoon.setValue(((Cartoon) Movie).c);
                this.QuantifyOfArtsValue.setText(String.valueOf(((Cartoon) Movie).QuantifyOfArts));
            }
        }
    }


    public Movie getMovie() {
        Movie result = null;
        String nameMovie = this.nameMovieText.getText();
        int price=Integer.parseInt(this.priceValue.getText());
        if(this.cmbMovieObjType.getValue()==  Movie_Fiction_Film){
            String producer =this.producerValue.getText();
            int QuantifyOfPerson= Integer.parseInt(this.QuantifyOfPersonValue.getText());
            result = new Fiction_Film (nameMovie, price,producer, QuantifyOfPerson);
        }
        if(this.cmbMovieObjType.getValue()==  Movie_Cartoon){
            int QuantifyOfArts = Integer.parseInt(this.QuantifyOfArtsValue.getText());
            result = new Cartoon (nameMovie, price,(Cartoon.TypeOfCartoon)this.cmbTypeOfCartoon.getValue(),QuantifyOfArts );
        }

        return result;
    }


    public void onCancelClick(javafx.event.ActionEvent event) {
        ((Stage)((Node)event.getSource()).getScene().getWindow()).close();
    }

    public void onSaveClick(javafx.event.ActionEvent event) {
        try{
            System.out.println("onSaveClick.id1="+id);
            if(this.id != null) {
                Movie Movie = getMovie ();
                Movie.id = this.id;
                System.out.println("onSaveClick.id2="+id);
                System.out.println("Пристуаем к изменениям");
                this.MovieObjModel.Edit(Movie);
            } else {
                this.MovieObjModel.add(getMovie());
            }
            ((Stage)((Node)event.getSource()).getScene().getWindow()).close();
        }
        catch (NumberFormatException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Не все поля были заполнены. Пожалуйста, введите все данные!");
            alert.showAndWait();
        } catch (NullPointerException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Не все поля заполнены. Повторите ввод!");
            alert.showAndWait();
        }
    }


    @FXML
    void KeyIntNumb(KeyEvent event)// ввод целых чисел
    {
        try {
            Integer.parseInt((event.getCharacter()));
        } catch (NumberFormatException e) {
            event.consume();
        }
    }

    public void KeyTemp() {
        Pattern p = Pattern.compile("(\\d+\\.?\\d*)?");
       nameMovieText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!p.matcher(newValue).matches()) nameMovieText.setText(oldValue);
        });
    }


}
