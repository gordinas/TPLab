package sample.GUI;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import sample.model.*;

import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutionException;

public class MainController implements Initializable {
    public TableView MainTable;
    public ComboBox cmbMovieObj;

    ObservableList<Class <? extends Movie>> MovieObjTypes = FXCollections.observableArrayList(
            Movie.class,
            Fiction_Film.class,
            Cartoon.class
    );
    // создали экземпляр класса модели
    MovieModel Movie= new MovieModel ();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // теперь вызываем метод, вместо прямого присваивания
        // прям как со всякими кнопочками
       Movie.addDataChangedListener(Computer -> {
           MainTable.setItems(FXCollections.observableArrayList(Computer));
       });
        TableColumn<Movie, String> nameComputer = new TableColumn<>("Удалённость от Земли (км)");
        //указываем какое поле брать у модели
        nameComputer.setCellValueFactory(new PropertyValueFactory<>("distanceFromEarth"));
        //Добавляем столбец с описанием
        TableColumn<Movie, String> descriptionColumn = new TableColumn<>("Описание");
        descriptionColumn.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getDescription());
        });

        //подцепляем столбцы к таблице
        MainTable.getColumns().addAll(nameComputer, descriptionColumn);


        cmbMovieObj.setItems(MovieObjTypes);
        cmbMovieObj.getSelectionModel().select(0);
        cmbMovieObj.setConverter(new StringConverter<Class>() {
            @Override
            public String toString(Class object) {
                if(Movie.class.equals(object)){
                    return "Все";
                } else if (Fiction_Film.class.equals(object)) {
                    return "Игровой фильм";
                } else if (Cartoon.class.equals(object)) {
                    return "Мультфильм";
                }
                return null;
            }

            @Override
            public Class fromString(String string) {
                return null;
            }
        });

        cmbMovieObj.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            this.Movie.setMovieObjFilter((Class<? extends Movie>) newValue);
        });
    }

    // добавляем инфу что наш код может выбросить ошибку IOException
    public void onAddClick()  throws IOException{
        System.out.println("Добавление строки");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ComputerForm.fxml"));
        Parent root = loader.load();
        // ну а тут создаем новое окно
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        // указываем что оно модальное
        stage.initModality(Modality.WINDOW_MODAL);
        // указываем что оно должно блокировать главное окно
        // ну если точнее, то окно, на котором мы нажали на кнопку
        stage.initOwner(this.MainTable.getScene().getWindow());
        ComputerController controller = loader.getController();
        controller.MovieObjModel= Movie;
        // открываем окно и ждем пока его закроют
        stage.showAndWait();
    }

    public void onEditClick() throws IOException {
        try {
            System.out.println("Изменение строки");
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ComputerForm.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(this.MainTable.getScene().getWindow());
            ComputerController controller = loader.getController();
            controller.setMovie((Movie) this.MainTable.getSelectionModel().getSelectedItem());
            controller.MovieObjModel = this.Movie;
            stage.showAndWait();

        } catch (NullPointerException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Вы не выбрали, чтоб изменить элемент. Выберите!");
            alert.showAndWait();
        }
    }

    public void onDeleteClick()throws InterruptedException,
            ExecutionException {
        Alert alert;
        try {
            Movie Movie = (Movie) this.MainTable.getSelectionModel().getSelectedItem();
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение");
            alert.setHeaderText(String.format("Точно удалить: %s?", Movie.getDescription()));
            Optional<ButtonType> option = alert.showAndWait();
            if (option.get() == ButtonType.OK) {
                this.Movie.Delete(Movie);
            }
        } catch (NullPointerException var4) {
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Ошибка!");
            alert.setContentText("Вы не выбрали, чтоб удалить. Выберите!");
            alert.showAndWait();
        }

    }

    public void onSaveToFileClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Сохранить данные");
        fileChooser.setInitialDirectory(new File("."));
        File file = fileChooser.showSaveDialog(MainTable.getScene().getWindow());
        if (file != null) {
            Movie.saveToFile(file.getPath());
        }
    }

    public void onLoadToFileClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Загрузить данные");
        fileChooser.setInitialDirectory(new File("."));
        File file = fileChooser.showOpenDialog(MainTable.getScene().getWindow());
        if (file != null) {
            Movie.loadFromFile(file.getPath());
        }
    }

    public void onCloseClick()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение");
        alert.setHeaderText(String.format("Точно закрыть окно программы?"));
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get() == ButtonType.OK) {
            System.exit(1);
        }
    }

}
