package sample.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

// тут написано что создай свойство @class и пропиши в нем имя класса
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include= JsonTypeInfo.As.PROPERTY, property="@class")
@JsonIgnoreProperties({"description"}) // указали что свойство description нужно игнорировать

public  class Movie {


    public Movie() {

    }



    public String nameMovie;
    public int price;
   public Integer id = null;


    public String getnameMovie(){return nameMovie;}
    public void setnameMovie(String nameMovie) {this.nameMovie = nameMovie;}
    public int getPrice(){return price;}
    public void setPrice(int price) {this.price = price;}


    public Movie(String nameMovie,int price) {this.setnameMovie(nameMovie);
        setPrice(price);}



    public String getDescription() {
        return "";
    }
    @Override
    public String toString() {
        return String.format("%s ", this.getnameMovie());
    }
}