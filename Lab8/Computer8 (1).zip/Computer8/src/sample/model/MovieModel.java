package sample.model;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class MovieModel {

    ArrayList<Movie> MovieObjList = new ArrayList<>();
    private int counter = 1;  // добавили счетчик

    Class<? extends Movie>MovieObjFilter = Movie.class;
    // Создаем функциональный интерфейс
    // с помощью него мы организуем общение между моделью и контроллером
    public interface DataChangedListener {
        void dataChanged(ArrayList<Movie> WeatherList);
    }
    // Меняем на private и делаем список
    private ArrayList<DataChangedListener> dataChangedListeners = new ArrayList<>();
    // добавляем метод который позволяет привязать слушателя
    public void addDataChangedListener(DataChangedListener listener) {
        // в список добавляем
        this.dataChangedListeners.add(listener);
    }

    public  void add(Movie Movie, boolean emit) {
        Movie.id = counter;
        System.out.println("add.id="+Movie.id);
        counter += 1;
        this.MovieObjList.add(Movie);
        if(emit)
        {
            this.emitDataChanged();
        }
    }

    public void add(Movie Movie) {
        add(Movie, true);
    }

    public void Edit(Movie Movie) {
        System.out.println("Запущен Edit");
        // ищем объект в списке
        for (int i = 0; i< this.MovieObjList.size(); ++i) {
            // чтобы id совпадал с id переданным форме
            System.out.println("i=   "+this.MovieObjList.get(i).id+"id=    "+Movie.id);
            if (this.MovieObjList.get(i).id == Movie.id) {

                // если нашли, то подменяем объект
                this.MovieObjList.set(i, Movie);
                break;
            }
        }
        this.emitDataChanged();
    }
    private static class Result {
        private final int wait;
        public Result(int code) {
            this.wait = code;
        }
    }
    private static final Random PRNG = new Random();
    public static Result compute(Object obj) throws InterruptedException {
        int wait = PRNG.nextInt(3000);
        Thread.sleep(wait);
        return new Result(wait);
    }
    public void Delete (Movie Movie) throws InterruptedException,
            ExecutionException
    {
        List<Object> objects = new ArrayList<Object>();
        for (int i = 0; i < this.MovieObjList.size(); i++) {
            objects.add(new Object());
        }

        List<Callable<Result>> tasks = new ArrayList<Callable<Result>>();
        for (final Object object : objects) {
            Callable<Result> c = new Callable<Result>() {
                @Override
                public Result call() throws Exception {
                    return compute(object);
                }
            };
            tasks.add(c);
        }

        ExecutorService exec = Executors.newCachedThreadPool();
        // some other exectuors you could try to see the different behaviours
        // ExecutorService exec = Executors.newFixedThreadPool(3);
        // ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            long start = System.currentTimeMillis();
            List<Future<Result>> results = exec.invokeAll(tasks);
            int sum = 0;
            for (int i = 0; i < this.MovieObjList.size(); i++) {
                System.out.println("Delete Movie.id="+Movie.id);
                if (this.MovieObjList.get(i).id == Movie.id) {
                    // если нашли то удаляем
                    this.MovieObjList.remove(i);
                    break;
                }
            }
            long elapsed = System.currentTimeMillis() - start;
            System.out.println(String.format("Elapsed time: %d ms", elapsed));
            System.out.println(String.format("... but compute tasks waited for total of %d ms; speed-up of %.2fx", sum, sum / (elapsed * 1d)));
        } finally {
            exec.shutdown();
        }
        for (int i = 0; i< this.MovieObjList.size(); ++i) {
            // чтобы id совпадал с id переданным форме
            System.out.println("i=  "+MovieObjList.get(i).id+"id=  "+Movie.id);
            if (this.MovieObjList.get(i).id == Movie.id) {
                // если нашли, то подменяем объект
                System.out.println("Совпало");
                this.MovieObjList.set(i, Movie);
                break;
            }
        }
        this.emitDataChanged();
    }

    public void saveToFile(String path) {
        // открываем файл для чтения
        try (Writer writer =  new FileWriter(path)) {
            // создаем сериализатор
            ObjectMapper mapper = new ObjectMapper();
            mapper.writerFor(new TypeReference<ArrayList<Movie>>() { }) // указали какой тип подсовываем
                    .withDefaultPrettyPrinter() // кстати эта строчка чтобы в файлике все красиво печаталось
                    .writeValue(writer, MovieObjList); // а это непосредственно запись
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile(String path) {
        try (Reader reader =  new FileReader(path)) {
            // создаем сериализатор
            ObjectMapper mapper = new ObjectMapper();
            // читаем из файла
            MovieObjList = mapper.readerFor(new TypeReference<ArrayList<Movie>>() { })
                    .readValue(reader);
            this.counter = MovieObjList.stream()
                    .map(Movie ->Movie.id)
                    .max(Integer::compareTo)
                    .orElse(0) + 1;
        } catch (IOException e) {
            e.printStackTrace();
        }
        // оповещаем что данные загрузились
        this.emitDataChanged();
    }

    public void setMovieObjFilter(Class<? extends Movie> ComputerObjFilter) {
        this.MovieObjFilter = ComputerObjFilter;
        this.emitDataChanged();
    }

    private void emitDataChanged() {
        Iterator var1 = this.dataChangedListeners.iterator();

        while(var1.hasNext()) {
            MovieModel.DataChangedListener listener = (MovieModel.DataChangedListener)var1.next();
            ArrayList<Movie> filterEdList = new ArrayList((Collection)this.MovieObjList.stream().filter((Movie) -> {
                return this.MovieObjFilter.isInstance(Movie);
            }).collect(Collectors.toList()));
            listener.dataChanged(filterEdList);
        }
    }
}
