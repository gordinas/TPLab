package sample.model;

public class Cartoon  extends Movie {
    public int QuantifyOfArts;
    public enum  TypeOfCartoon{Рисованный, Кукольный, Пластилиновый};
    public TypeOfCartoon c;

    Cartoon() {
    }

    public Cartoon(String nameMovie, int price,TypeOfCartoon c,int QuantityOfArts) {
        super(nameMovie,price);
        this.c = c;
        this.QuantifyOfArts = QuantityOfArts;
    }

    @Override
    public String getDescription() {
        String nameMovie=this.nameMovie;
        int price=this.price;
       int QuantifyOfArts=this.QuantifyOfArts;
        TypeOfCartoon c= this.c;
        return String.format("Мультфильм. Название фильма: %s; стоимость одного работника съемочной группы - %s; тип мультфильма- %s; количество художников - %s", nameMovie, price, c,QuantifyOfArts);
    }
}
