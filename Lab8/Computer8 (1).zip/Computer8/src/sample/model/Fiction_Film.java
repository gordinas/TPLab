package sample.model;

public class Fiction_Film  extends Movie {
     public String producer;
     public int QuantifyOfPerson;
    Fiction_Film(){}
    public Fiction_Film(String nameMovie, int price,String producer,int QuantifyOfPerson) {
        super(nameMovie,price);
        this.producer = producer;
        this.QuantifyOfPerson = QuantifyOfPerson;
    }
    @Override
    public String getDescription() {
        String nameMovie=this.nameMovie;
        int price=this.price;
        String producer=this.producer;
        int QuantifyOfPerson=this.QuantifyOfPerson;
        return String.format("Игровой фильм. Название фильма: %s; фамилия режиссера - %s; стоимость одного работника съемочной группы - %s;количество работников съемочной группы - %s; ",nameMovie, producer,price,QuantifyOfPerson);
    }




}