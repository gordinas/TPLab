package sample;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Orientation;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import sample.GUI.Controller;

public  class Main extends Application {


    public void start(Stage stage) throws Exception {
        System.out.println("Стартовал"  );
        Parent root = FXMLLoader.load(this.getClass().getResource("GUI/MainForm.fxml"));
        System.out.println("Запущен fxml"  );
        stage.setTitle ("Компьютеры");
        stage.setScene (new Scene (root));
        stage.show ( );

    }
    public static void main(String[] args) {
        launch (args);
    }


    }

