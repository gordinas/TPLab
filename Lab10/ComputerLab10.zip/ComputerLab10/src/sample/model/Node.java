package sample.model;

import javafx.scene.control.TreeItem;

import java.util.LinkedList;
import java.util.Queue;

public class Node extends TreeItem<Integer>{
    private int value; // ключ узла
    private Node  leftChild; // Левый узел потомок
    private Node rightChild; // Правый узел потомокк

    public Node (int value)
    {
        super(value);
        getChildren().add(0, new TreeItem<>(0));
        getChildren().add(1, new TreeItem<>(0));
    }
    public static void DeleteNull(TreeItem root)
    {
        Queue<TreeItem> q = new LinkedList<>();
        q.add(root);
        while (!q.isEmpty()) {
            TreeItem<Integer> item = q.remove();
            if (!item.getChildren().isEmpty()
                    && (item.getChildren().get(0).getValue() != 0
                    || item.getChildren().get(1).getValue() != 0)) {
                q.add(item.getChildren().get(0));
                q.add(item.getChildren().get(1));
            }
            if (!item.getChildren().isEmpty()
                    && item.getChildren().get(0).getValue() == 0
                    && item.getChildren().get(1).getValue() == 0) {
                item.getChildren().clear();
            }
        }
    }
    public static Node Add(Node current, int value)
    {
        if(current == null)
        {
            return new Node(value);
        }

        if(value < current.getValue()
                && !current.getChildren().isEmpty())
        {
            current.leftChild = Add(current.leftChild, value);
            current.getChildren().remove(0);
            current.getChildren().add(0, current.leftChild);
        }

        else if (value > current.getValue()
                && !current.getChildren().isEmpty())
        {
            current.rightChild = Add(current.rightChild, value);
            current.getChildren().remove(1);
            current.getChildren().add(1, current.rightChild);
        }

        else if (value < current.getValue()
                && current.getChildren().isEmpty())
        {
            current.getChildren().add(0, new TreeItem<>(0));
            current.getChildren().add(1, new TreeItem<>(0));
            current.leftChild = Add(current.leftChild, value);
            current.getChildren().remove(0);
            current.getChildren().add(0, current.leftChild);
        }
        else if (value > current.getValue()
                && current.getChildren().isEmpty())
        {
            current.getChildren().add(0, new TreeItem<>(0));
            current.getChildren().add(1, new TreeItem<>(0));
            current.rightChild = Add(current.rightChild, value);
            current.getChildren().remove(1);
            current.getChildren().add(1, current.rightChild);
        }
        else
        {
            return  current;
        }
        return current;
    }

    @Override
    public String toString() {
        return "Node{" +
                "value=" + value +
                ", leftChild=" + leftChild +
                ", rightChild=" + rightChild +
                '}';
    }
}