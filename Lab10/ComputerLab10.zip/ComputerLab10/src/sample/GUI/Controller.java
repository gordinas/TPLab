package sample.GUI;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import sample.model.Node;

import java.net.URL;
import java.util.*;

public class Controller implements Initializable {
    public TreeView<Integer> TreeBinary;
    public Button AddRandom;
    public Button AddFixed;
    public VBox VBRandAdd;
    public TextField CountRandEl;
    public VBox ActionTreeVB;
    public TextField SearchElTF;
    public TextField TextFAddEl;
    public Label lblPath;
    public Label lblMinChild;
    public Label lblWideSearch;

   Node root;



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TreeBinary.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            lblPath.setText("");
            if (newValue != null && newValue.getValue() != 0) {
                String path = String.valueOf(newValue.getValue());
                TreeItem<Integer> parent = newValue.getParent();
                while (parent != null) {
                    path = parent.getValue() + " : " + path;
                    parent = parent.getParent();
                }
                lblPath.setText("Путь до узла: " + path);
                lblPath.setVisible(true);
            }
        });

        TreeBinary.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            lblMinChild.setText("");
            if (newValue != null && newValue.getValue() != 0) {
                if (newValue.getChildren().isEmpty()) {
                    lblMinChild.setText("У данного узла нет потомков меньших по значению");
                } else {
                    TreeItem<Integer> currentItem = newValue;
                    TreeItem<Integer> currentItemCheck = newValue;

                    while (!currentItem.getChildren().isEmpty()) {
                        if (currentItem.getChildren().get(0).getValue() != 0)
                            currentItem = currentItem.getChildren().get(0);
                        else {
                            lblMinChild.setText("У данного узла нет потомков меньших по значению");
                            break;
                        }
                    }

                    if (currentItem != currentItemCheck)
                        lblMinChild.setText("Потомок с минимальным значением - " + String.valueOf(currentItem.getValue()));
                    else lblMinChild.setText("У данного узла нет потомков меньших по значению");
                }
            }

        });

        TreeBinary.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            lblWideSearch.setText("");
            if (newValue != null && newValue.getValue() != 0) {
                int i = 0;
                TreeItem<Integer> parent = newValue.getParent();

                while (parent != null) {
                    i++;
                    parent = parent.getParent();
                }

                Queue<TreeItem> q = new LinkedList<>();

                if (i == 0) {
                    lblWideSearch.setText(String.valueOf(root.getValue()));
                } else {
                    q.add(TreeBinary.getRoot());
                    ArrayList<TreeItem> elements = new ArrayList<>();

                    while (!q.isEmpty()) {
                        TreeItem<Integer> it = q.remove();
                        if (it.getValue() == 0) continue;
                        if (!it.getChildren().isEmpty()) {
                            q.add(it.getChildren().get(0));
                        }
                        if (it.getChildren().size() > 1) {
                            q.add(it.getChildren().get(1));
                        }
                        if (countRoot(it) == i) {
                            elements.add(it);
                        }
                    }
                    lblWideSearch.setText("Узлы того же уровня: " + getEl(elements));
                }
            }
        });

    }

    private int countRoot(TreeItem IT)
    {
        int i = 0;
        TreeItem<Integer> parent = IT.getParent();
        while ((parent != null))
        {
            i++;
            parent = parent.getParent();
        }
        return i;
    }

    private String getEl(List<TreeItem> el)
    {
        String str = "";
        for(TreeItem El : el)
        {
            str += El.getValue() + " ";
        }
        return str;
    }

    public void SearchRoot()
    {
        try{
            if(Integer.parseInt(SearchElTF.getText()) == root.getValue())
            {
                TreeBinary.getSelectionModel().select(root);
            } else if(Integer.parseInt(SearchElTF.getText()) < root.getValue())
            {
                search(root.getChildren().get(0), Integer.parseInt(SearchElTF.getText()));
            } else if (Integer.parseInt(SearchElTF.getText()) > root.getValue()) {
                search(root.getChildren().get(1), Integer.parseInt(SearchElTF.getText()));
            }
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Введите число!");
            alert.showAndWait();
        }
    }

    private void search(TreeItem<Integer> currentItem, int el)
    {
        try {
            if (el == currentItem.getValue()) {
                TreeBinary.getSelectionModel().select(currentItem);
            } else if (el < currentItem.getValue()) {
                search(currentItem.getChildren().get(0), el);
            } else if (el > currentItem.getValue()) {
                search(currentItem.getChildren().get(1), el);
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Элемент с значением " + String.valueOf(el) + " не найден!");
            alert.showAndWait();
        }
    }

    public void Add()
    {
        try{
           Node.Add(root, Integer.parseInt(TextFAddEl.getText()));
           Node.DeleteNull(root);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Узел " +TextFAddEl.getText() + " добавлен!");
            alert.showAndWait();
            TextFAddEl.setText("");
        }catch (NumberFormatException e)
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Введите число!");
            alert.showAndWait();
        }
    }

    public void CreateForFixedEl()
    {
        Queue<Integer> Values = new LinkedList<>();
        Integer[] arr = new Integer[]{10, 5, 20, 3, 7, 15, 25};
        for (int el : arr) {
            Values.add(el);
        }
        root = new Node(Values.remove());
        while (!Values.isEmpty()) {
            Node.Add(root, Values.remove());
        }
        Node.DeleteNull(root);
        TreeBinary.setRoot(root);
        root.setExpanded(true);
        AddFixed.setDisable(true);
        AddRandom.setDisable(false);
        VBRandAdd.setVisible(false);
        ActionTreeVB.setVisible(true);
    }

    public void CreateForRandEl()
    {
        VBRandAdd.setVisible(true);
    }

    public void createRandTree()
    {
        try {
            Integer[] arr = new Integer[Integer.parseInt(CountRandEl.getText())];
            Random rand = new Random();
            for (int i = 0; i < arr.length; i++){
                arr[i] = rand.nextInt(15);
            }
            Queue<Integer> Values = new LinkedList<>();
            for (int el : arr) {
                Values.add(el);
            }
            root = new Node(Values.remove());
            while (!Values.isEmpty()) {
                Node.Add(root, Values.remove());
            }
            Node.DeleteNull(root);
            TreeBinary.setRoot(root);
            root.setExpanded(true);
            AddRandom.setDisable(true);
            AddFixed.setDisable(false);
            CountRandEl.setText("");
            VBRandAdd.setVisible(false);
            ActionTreeVB.setVisible(true);
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Введите число!");
            alert.showAndWait();
        }
    }
}
