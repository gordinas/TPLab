package sample.model;

import sample.Main;

public class Tablet extends Computer {
    public static boolean camera;
    public static int dpi;
    public Tablet(String namecomputer,boolean camera, int dpi) {
        this.nameComputer =namecomputer;
        this.camera =camera;
        this.dpi =dpi ;

    }
    Tablet(){};
    @Override
    public String getDescription() {
        boolean camera =  this.camera;
        int dpi = this.dpi;
        return String.format("Планшет. Наличие камеры: %s; dpi - %s; ",camera, dpi);
    }

}
