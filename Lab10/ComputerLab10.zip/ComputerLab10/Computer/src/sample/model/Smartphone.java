package sample.model;
import sample.Main;

public class Smartphone  extends Computer {
    public static int n_slot;
    public static double mpx;
    public static Main.battery b;
    Smartphone(){}
    public Smartphone(String namecomputer,int n_slot, double mpx, Main.battery b) {
        super.setnameComputer(namecomputer);
        this. n_slot = n_slot;
        this.mpx = mpx;
        this.b =b;
    }
    @Override
    public String getDescription() {
        int n_slot =  this.n_slot;
        double mpx = this.mpx;
        Main.battery b= this.b;
        return String.format("Смартфон. Число слотов: %s; mpx - %s; батарея- %s ",n_slot, mpx,b);
    }





}