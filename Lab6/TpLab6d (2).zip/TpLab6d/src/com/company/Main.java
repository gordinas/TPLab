package com.company;
import java.util.Scanner;

import static com.company.Cartoon.TypeOfCartoon.*;

public class Main {

private static boolean stop;
    private static boolean stoprecord;
private static Integer t ;
public static int price;
public static int i =0;

private static boolean recording;
public static  String namemovie;
public static  String producer;
 public static   int QuantifyOfPerson;
    private static int m;
    public static boolean was=false;
    public static Cartoon.TypeOfCartoon c;
    public static int QuantifyOfArts;
    private static Movie[] objs = new Movie[4];
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        do{
        do{m= readIntFromConsol("Если вы хотите создать объекты нажмите 1","Если вы хотите изменить объекты нажмите 2","Если вы хотите вывести список объектов на экран нажмите 3","Если вы хотите посчитать стоимость фильма нажмите 4","Если хотите выйти нажмите 5");}
        while((m<0)||(m>6));
switch (m){
    case 1:
        addObj();
  break;
    case 2:if(!was){
        System.out.println("Объекты еще не созданы!");
    }else
        changeObg();
        break;
    case 3:
        if(!was){
            System.out.println("Объекты еще не созданы!");
        }else printObg();
        break;
    case 4:
        if(!was){
        System.out.println("Объекты еще не созданы!");
    }else
        Cost();
        break;
    case 5:
        System.out.println("Вы завершили выполнение программы!");
        System.exit(0);
        break;
    default:
        break;
}}while(true);



	// write your code here


    }
    public static void addObj()
    {
        Scanner in = new Scanner(System.in);
        if(!was)
        {
            addF();
            addC();
            was=true;
        }
        else
        {
            boolean Menu;

                Menu = false;
            int m1;
                do{
               m1= readIntFromConsol("Если вы хотите перезаписать объекты нажмите 1","Если не хотите перезаписать объекты нажмите 2");
                    System.out.println(m1);
                }while (!((m1==1)||(m1==2)));
                switch (m1){
                    case 1:
                        System.out.println("Начало");
                        addF();
                        addC();
                        System.out.println("Конец");
                        break;
                    case 2:
                        break;
                    default:
                        System.out.println("Вы ввели неверное число! введите еще раз, пожалуйста!");
                }

        }
    }
    public static void addF()
    {
        Scanner in = new Scanner(System.in);
        for(i=0;i<2;i++){

            boolean correcting= true;
            do{
                System.out.println("Введите название игрового фильма");
                namemovie= in.next();
                System.out.println("Введите фамилию режиссера");
                producer= in.next();
                do{price=readIntFromConsol("Введите стомость одного работника съемочной группы");}
                while(!(price>-1));
                do{
                    QuantifyOfPerson=readIntFromConsol("Введите  число работников съемочной группы");
                }while(!(QuantifyOfPerson>0));
                try {
                    objs[i] = new Fiction_Film(namemovie, price, producer, QuantifyOfPerson);
                } catch (IllegalArgumentException e) {
                    correcting = false;
                    System.out.println(e.getMessage());
                } catch (Exception e) {
                    correcting = false;
                    System.out.println("Введие заново!");
                }}while(!correcting);



    }
    }
    public static void addC()
    {
        for(i=0;i<2;i++) {
            Scanner in= new Scanner(System.in);
            boolean correcting= true;
            do {
                int type;
                do{type=    readIntFromConsol("Если фильм рисованный нажмите 1","Если фильм кукольный нажмите 2","Если фильм пластилиновый нажмите 3");}
                while((type>3) || (type<0));
                switch(type){
                    case 1:
                        c=drawn;
                        break;
                    case 2:
                        c=upped;
                        break;
                    case 3:
                        c=plastilin;
                        break;

                }
                System.out.println("Введите название мультфильма");
                namemovie= in.next();
                price = readIntFromConsol("Введите стомость одного работника съемочной группы");
                QuantifyOfArts = readIntFromConsol("Введите  число работников съемочной группы");

                try {
                    objs[i+2] = new Cartoon(namemovie, price, c, QuantifyOfPerson);
                } catch (IllegalArgumentException e) {
                    correcting = false;
                    System.out.println(e.getMessage());
                } catch (Exception e) {
                    correcting = false;
                    System.out.println("Введие заново!");
                }}while(!correcting);


        }

    }
    protected static Integer readIntFromConsol (String a) {
        t =0;
        stop= false;
        while(!stop){
            System.out.println(a);
            readIntFromConsoleReduce(1);

        }

        return t;
    }
    public static Integer readIntFromConsol (String a, String b) {
        Scanner in = new Scanner(System.in);
         t =0;
       stop= false;
        while(!stop){
            System.out.println(a);
            System.out.println(b);
            readIntFromConsoleReduce(1);
            System.out.println(t);
        }

        return t;
    }
    public static Integer readIntFromConsol (String a, String b,String c) {
        Scanner in = new Scanner(System.in);
         t =0;
        stop= false;
        while(!stop){
            System.out.println(a);
            System.out.println(b);
            System.out.println(c);
            readIntFromConsoleReduce(1);
        }

        return t;
    }

    public static Integer readIntFromConsol (String a, String b,String c,String d) {
        Scanner in = new Scanner(System.in);
          t =0;
         stop= false;
        while(!stop){
            System.out.println(a);
            System.out.println(b);
            System.out.println(c);
            System.out.println(d);
            readIntFromConsoleReduce(1 );
        }

        return t;
    }
    public static Integer readIntFromConsol (String a, String b,String c,String d, String e) {
        Scanner in = new Scanner(System.in);
        t =0;
        stop= false;
        while(!stop){
            System.out.println(a);
            System.out.println(b);
            System.out.println(c);
            System.out.println(d);
            System.out.println(e);
            readIntFromConsoleReduce(1 );
        }

        return t;
    }
    public static Integer readIntFromConsol () {
        Scanner in = new Scanner(System.in);
        t =0;
        stop= false;
        while(stop){
            readIntFromConsoleReduce(1 );
        }

        return t;
    }
    public static void readRecording () {
        t =-1;
        stoprecord= false;
        do{
            do {

            System.out.println("Если вы хотите добавить запись нажмите 1");
            System.out.println("Если вы не хотите добавить запись нажмите 0");
            readIntFromConsoleReduce(2);
                System.out.println("stop="+stop);
                System.out.println("t="+t);
            }while(!stoprecord);

        }
        while (!((t==0)||(t==1)));


        if(t==1){
            recording= true;
        }
        else{
            recording= false;
        }
    }
    public static void readIntFromConsoleReduce( int sw){
        Scanner in = new Scanner(System.in);
        try
        {String ts= in.next();;
        t= Integer.parseInt(ts);
        switch(sw){
            case 1:
                stop=true;break;
            case 2:
                stoprecord=true;
                break;
            default: break;
        }
          stop=true;

        }
        catch(NumberFormatException e)
        {

        }

    }
    public static void changeObg()
    {
        if(objs.length==0)
        {
            System.out.println("Объекты не существуют!");
        }
        else
        {

            printObg();
            boolean availability;
            int num;
            do {
                availability = true;
                num =readIntFromConsol("Введите № объекта, который хотете изменить!","№ объекта: ");
                if(availability && num > 0 && num < 5){
                    if(objs[num-1 ] instanceof Fiction_Film) changeF(num-1);
                    if(objs[num-1 ] instanceof Cartoon) changeC(num-1 );}


                else
                {
                    System.out.println("Номер этого объетка не найден!");
                    availability = false;
                }
            }while (!availability);




        }
    }

    public static void printObg()
    {
        for (int i = 0; i < objs.length; i++) {
            System.out.println((i + 1) + ". " + objs[i].info());
        }
    }
    public static void changeF(int k)
    {
        System.out.println(objs[k].info());
        boolean Menu;
        Scanner in = new Scanner(System.in);

         int mF;
           do{mF=readIntFromConsol ("Если вы хотите изменить название фильма нажмите 1","Если вы хотите изменить фамилию режиссера нажмите 2","Если вы хотите изменит стоимость одного работника съемочной группы нажмите 3 ","Если вы хотите изменить число работников съемочной группы нажмите 4");}
           while(!((mF>0)||(mF<4)));
            boolean writing;
            switch (mF)
            {
                case 1:
                    System.out.println("Введите название фильма");

                    do {
                        writing =true;
                        System.out.print("Введите название фильма");

                        try {
                            Fiction_Film s = (Fiction_Film) objs[k];
                            s.setnamemovie(in.next());
                            System.out.println("Название фильма изменено");
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage() + "Введите заново!");
                            writing = false;
                        } catch (Exception e) {
                            System.out.println("Ошибка, введите заново!");
                            writing = false;
                        }
                    } while (!writing);
                    break;
                case 2:
                    System.out.println("Введите фамилию режиссера");
                    do {
                        writing =true;
                        System.out.print("Изменить фамилию режиссера");

                        try {
                            Fiction_Film s = (Fiction_Film) objs[k];
                            s.setproducer(in.next());
                            System.out.println("Фамилия режиссера изменена");
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage() + "Введите заново!");
                            writing = false;
                        } catch (Exception e) {
                            System.out.println("Ошибка, введите заново!");
                            writing = false;
                        }
                    } while (!writing);
                    break;
                case 3:
                    System.out.println("Введите стоимость одного работника");

                    do {
                        writing =true;

                        try { Fiction_Film s = (Fiction_Film) objs[k];
                            int send;
                            do{send=readIntFromConsol("Изменить cтоимость одного работника");}
                            while(send<0);
                            s.setprice(send);
                            System.out.println("Стоимость одного работника изменена");
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage() + "Введите заново!");
                            writing = false;
                        } catch (Exception e) {
                            System.out.println("Ошибка, введите заново!");
                            writing = false;
                        }
                    } while (!writing);
                    break;
                case 4 :
                    System.out.println("Введите количество работников съемочной группы");

                    do {
                        writing =true;

                        try {Fiction_Film s = (Fiction_Film) objs[k];
                            int send;
                            do{send=readIntFromConsol("Изменить количество работников съемочной группы");}
                            while(send<1);
                            s.setQuantityOfPerson(send);
                            System.out.println("Количество работников изменено");
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage() + "Введите заново!");
                            writing = false;
                        } catch (Exception e) {
                            System.out.println("Ошибка, введите заново!");
                            writing = false;
                        }
                    } while (!writing);
                    break;
                default:

            }

    }
    public static void changeC(int k)
    {
        System.out.println(objs[k].info());
        boolean Menu;
        Scanner in = new Scanner(System.in);

        int mС;
        do{mС=readIntFromConsol ("Если вы хотите изменить название фильма нажмите 1","Если вы хотите изменить тип мультфильма 2","Если вы хотите изменит стоимость одного работника съемочной группы нажмите 3 ","Если вы хотите изменить число работников съемочной группы нажмите 4");}
        while((mС<0)||(mС>4));
        boolean writing;
        switch (mС)
        {
            case 1:
                System.out.print("Введите название мультфильма");
                do {
                    writing =true;
                    System.out.print("Изменить название мультфильма");
                    try {
                        Cartoon s = (Cartoon) objs[k];
                        s.setnamemovie(in.next());
                        System.out.println("Название мультфильма изменено ");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage() + "Введите заново!");
                        writing = false;
                    } catch (Exception e) {
                        System.out.println("Ошибка, введите заново!");
                        writing = false;
                    }
                } while (!writing);
                break;
            case 2:
                System.out.println("Введите тип мультфильма");
                do {
                    writing =true;
                    System.out.print("Изменить тип мультфильма ");
                    try {
                        Cartoon s = (Cartoon) objs[k];
                        int type;
                        do{type=    readIntFromConsol("Если фильм рисованный нажмите 1","Если фильм кукольный нажмите 2","Если фильм пластилиновый нажмите 3");}
                        while((type>3) ||(type<0));
                        switch(type){
                            case 1:
                                c=drawn;
                                break;
                            case 2:
                                c=upped;
                                break;
                            case 3:
                                c=plastilin;
                                break;

                        }
                        s.setTypeOfCartoon(c);
                        System.out.println("Тип мультфильма изменен");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage() + "Введите заново!");
                        writing = false;
                    } catch (Exception e) {
                        System.out.println("Ошибка, введите заново!");
                        writing = false;
                    }
                } while (!writing);
                break;
            case 3:
                System.out.println("Введите стоимость одного художника");

                do {
                    writing =true;
                    Cartoon s = (Cartoon) objs[k];
                    try {
                        int send;
                        do{send=readIntFromConsol("Изменить cтоимость одного работника");}
                        while(send<0);
                        System.out.println("Стоимость одного художника изменена");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage() + "Введите заново!");
                        writing = false;
                    } catch (Exception e) {
                        System.out.println("Ошибка, введите заново!");
                        writing = false;
                    }
                } while (!writing);
                break;
            case 4 :
                System.out.println("Введите число художников");

                do {
                    writing =true;
                   Cartoon s = (Cartoon) objs[k];
                    try {
                        int send;
                        do{send=readIntFromConsol("Изменить число художников");}
                        while(send<1);
                        s.setQuantifyOfArts(send);

                        System.out.println("Количество художников изменено");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage() + "Введите заново!");
                        writing = false;
                    } catch (Exception e) {
                        System.out.println("Ошибка, введите заново!");
                        writing = false;
                    }
                } while (!writing);
                break;
            default:

        }

    }
    public static void Cost()
    {
        if (!was)
        {
            System.out.println("Объекты еще не созданы!");
        } else
        {
            printObg();
            for (int i = 0; i < 4; i++)
            {
                Cost m = (Cost) objs[i];
                System.out.println("Фильм  " + (i + 1) + " Стоимость фильма =  " + m.cost());
            }
        }
    }

}