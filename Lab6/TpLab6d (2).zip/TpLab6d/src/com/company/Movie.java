package com.company;

public class Movie implements Cost  {
    protected  String namemovie;
    protected  int price;
    protected  int C;
    public Movie(String namemovie,int price){
        this.namemovie = namemovie;
        this.price = price;}
    public int cost()
    {
        return getC();
    }
    public int getC(){
        return C;
    }
    public  String getnamemovie(){
       return namemovie;
    }
    public  int getprice( ) {
        return price;
    }
    protected  void setnamemovie( String namemovie){
        this.namemovie= namemovie;
    }
    public void setprice(int price) {
        this.price = price;
    }
    public  String info()
    {
        return "Стоимость фильма= " +getC();
    }

}