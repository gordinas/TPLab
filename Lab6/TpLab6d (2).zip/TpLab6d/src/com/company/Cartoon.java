package com.company;

public class Cartoon extends Movie {
    public Cartoon(String namemovie, int price,TypeOfCartoon c,int QuantityOfArts) {
        super (namemovie, price);
        this.setTypeOfCartoon(c);
        this.setQuantifyOfArts(QuantityOfArts);
    }

    private int QuantifyOfArts;
    enum  TypeOfCartoon{drawn,upped,plastilin};
    TypeOfCartoon c;


    public int getQuantifyOfArts(){
        return QuantifyOfArts;
    }
    public TypeOfCartoon getTypeOfCartoon(){
        return c;
    }
    public void  setQuantifyOfArts(int QuantifyOfArts){
        this.QuantifyOfArts= QuantifyOfArts;
    }
    public void setTypeOfCartoon(TypeOfCartoon c){
        this.c= c;
    }


    public String info()
    {String sType="";
    switch(c){
        case drawn:
            sType="Рисованный";
            break;
        case upped:
            sType="Кукольный";
            break;
        case plastilin:
            sType="Пластилиновый";
            break;
            default:
        break;

    }
        return  "Мультфильм    "  + "    ; название :   " + super.getnamemovie() + "     Тип мультфильма:   "+sType+ ";      стоимость одного работника = " + super.getprice()+"   число художников    " + getQuantifyOfArts();
    }

    public  int cost(){
        return getQuantifyOfArts()*getprice();
    }

}
