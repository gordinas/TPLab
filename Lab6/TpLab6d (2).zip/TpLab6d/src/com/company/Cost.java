package com.company;

public interface Cost  {
   int cost();
}



