package sample.model;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.stream.Collectors;

public class ComputerModel {

    ArrayList<Computer> ComputerObjList = new ArrayList<>();
    private int counter = 1;  // добавили счетчик

    Class<? extends Computer>ComputerObjFilter = Computer.class;
    // Создаем функциональный интерфейс
    // с помощью него мы организуем общение между моделью и контроллером
    public interface DataChangedListener {
        void dataChanged(ArrayList<Computer> WeatherList);
    }
    // Меняем на private и делаем список
    private ArrayList<DataChangedListener> dataChangedListeners = new ArrayList<>();
    // добавляем метод который позволяет привязать слушателя
  public void addDataChangedListener(DataChangedListener listener) {
        // в список добавляем
        this.dataChangedListeners.add(listener);
    }

    public  void add(Computer Computer, boolean emit) {
        Computer.id = counter;
        counter += 1;
        this.ComputerObjList.add(Computer);
        if(emit)
        {
            this.emitDataChanged();
        }
    }

   public void add(Computer Computer) {
     add(Computer, true);
   }

    public void Edit(Computer Computer) {
        // ищем объект в списке
        for (int i = 0; i< this.ComputerObjList.size(); ++i) {
            // чтобы id совпадал с id переданным форме
            if (this.ComputerObjList.get(i).id == Computer.id) {
                // если нашли, то подменяем объект
                this.ComputerObjList.set(i, Computer);
                break;
            }
        }
        this.emitDataChanged();
    }

    public void Delete (int id)
    {
        for (int i = 0; i< this.ComputerObjList.size(); ++i) {
            // ищем в цикле еду с данным айдишником
            if (this.ComputerObjList.get(i).id == id) {
                // если нашли то удаляем
                this.ComputerObjList.remove(i);
                break;
            }
        }
        // оповещаем об изменениях
        this.emitDataChanged();
    }

    public void saveToFile(String path) {
        // открываем файл для чтения
        try (Writer writer =  new FileWriter(path)) {
            // создаем сериализатор
            ObjectMapper mapper = new ObjectMapper();
            mapper.writerFor(new TypeReference<ArrayList<Computer>>() { }) // указали какой тип подсовываем
                    .withDefaultPrettyPrinter() // кстати эта строчка чтобы в файлике все красиво печаталось
                    .writeValue(writer, ComputerObjList); // а это непосредственно запись
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile(String path) {
        try (Reader reader =  new FileReader(path)) {
            // создаем сериализатор
            ObjectMapper mapper = new ObjectMapper();
            // читаем из файла
            ComputerObjList = mapper.readerFor(new TypeReference<ArrayList<Computer>>() { })
                    .readValue(reader);
            this.counter = ComputerObjList.stream()
                    .map(Computer -> Computer.id)
                    .max(Integer::compareTo)
                    .orElse(0) + 1;
        } catch (IOException e) {
            e.printStackTrace();
        }
        // оповещаем что данные загрузились
        this.emitDataChanged();
    }

    public void setComputerObjFilter(Class<? extends Computer> ComputerObjFilter) {
        this.ComputerObjFilter = ComputerObjFilter;
        this.emitDataChanged();
    }

    private void emitDataChanged() {
       Iterator var1 = this.dataChangedListeners.iterator();

       while(var1.hasNext()) {
            ComputerModel.DataChangedListener listener = (ComputerModel.DataChangedListener)var1.next();
            ArrayList<Computer> filterEdList = new ArrayList((Collection)this.ComputerObjList.stream().filter((Computer) -> {
               return this.ComputerObjFilter.isInstance(Computer);
            }).collect(Collectors.toList()));
            listener.dataChanged(filterEdList);
       }
   }
}
