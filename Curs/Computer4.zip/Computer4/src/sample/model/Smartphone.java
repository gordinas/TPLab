package sample.model;
import sample.Main;

public class Smartphone  extends Computer {
    public int n_slot;
    public  double mpx;
    public battery Battery;
Smartphone(){}
    public Smartphone(String namecomputer,int n_slot, double mpx,battery b) {
        super(namecomputer);
        this. n_slot = n_slot;
        this.mpx = mpx;
        this.Battery = b;
    }
    public enum battery {
        SLA ("свинцово-кислотный аккумулятор"),
        NiCD ("никелево кадмиевый аккумулятор"),
        NiMH ("металло-гидридный аккумулятор"),
        li_ion ("литий-ионный аккумулятор");


        public String getRuName() {
            return ruName;
        }

        private String ruName;
        battery(String theRuName){
            this.ruName = theRuName;
        }
    }
    @Override
    public String getDescription() {
        int n_slot =  this.n_slot;
        double mpx = this.mpx;
        battery b= this.Battery;
        return String.format("Смартфон. Число слотов: %s; mpx - %s; батарея- %s ",n_slot, mpx,b);
    }





}