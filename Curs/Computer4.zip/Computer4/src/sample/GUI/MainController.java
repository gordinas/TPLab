package sample.GUI;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import sample.model.*;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    public TableView MainTable;
    public ComboBox cmbComputerObj;

    ObservableList<Class <? extends Computer>> ComputerObjTypes = FXCollections.observableArrayList(
            Computer.class,
            Laptop.class,
            Smartphone.class,
           Tablet.class
    );
    // создали экземпляр класса модели
    ComputerModel Computer= new ComputerModel ();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // теперь вызываем метод, вместо прямого присваивания
        // прям как со всякими кнопочками
       Computer.addDataChangedListener(Computer -> {
           MainTable.setItems(FXCollections.observableArrayList(Computer));
       });
        TableColumn<Computer, String> nameComputer = new TableColumn<>("Удалённость от Земли (км)");
        //указываем какое поле брать у модели
        nameComputer.setCellValueFactory(new PropertyValueFactory<>("distanceFromEarth"));
        //Добавляем столбец с описанием
        TableColumn<Computer, String> descriptionColumn = new TableColumn<>("Описание");
        descriptionColumn.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().getDescription());
        });

        //подцепляем столбцы к таблице
        MainTable.getColumns().addAll(nameComputer, descriptionColumn);

        cmbComputerObj.setItems(ComputerObjTypes);
        cmbComputerObj.getSelectionModel().select(0);
        cmbComputerObj.setConverter(new StringConverter<Class>() {
            @Override
            public String toString(Class object) {
                if(Computer.class.equals(object)){
                    return "Все";
                } else if (Laptop.class.equals(object)) {
                    return "Ноутбук";
                } else if (Smartphone.class.equals(object)) {
                    return "Смартфон ";
                } else if (Tablet.class.equals(object)) {
                    return "Планшетный компьютер";
                }
                return null;
            }

            @Override
            public Class fromString(String string) {
                return null;
            }
        });

        cmbComputerObj.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            this.Computer.setComputerObjFilter((Class<? extends Computer>) newValue);
        });
    }

    // добавляем инфу что наш код может выбросить ошибку IOException
    public void onAddClick()  throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ComputerForm.fxml"));
        Parent root = loader.load();
        // ну а тут создаем новое окно
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        // указываем что оно модальное
        stage.initModality(Modality.WINDOW_MODAL);
        // указываем что оно должно блокировать главное окно
        // ну если точнее, то окно, на котором мы нажали на кнопку
        stage.initOwner(this.MainTable.getScene().getWindow());

        ComputerController controller = loader.getController();
        controller.ComputerObjModel= Computer;

        // открываем окно и ждем пока его закроют
        stage.showAndWait();
    }

    public void onEditClick() throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ComputerForm.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(this.MainTable.getScene().getWindow());
            ComputerController controller = loader.getController();
            controller.setСomputer((Computer) this.MainTable.getSelectionModel().getSelectedItem());
            controller.ComputerObjModel = this.Computer;
            stage.showAndWait();
        } catch (NullPointerException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Вы не выбрали, чтоб изменить элемент. Выберите!");
            alert.showAndWait();
        }
    }

    public void onDeleteClick() {
        Alert alert;
        try {
            Computer Computer = (Computer)this.MainTable.getSelectionModel().getSelectedItem();
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение");
            alert.setHeaderText(String.format("Точно удалить: %s?", Computer.getDescription()));
            Optional<ButtonType> option = alert.showAndWait();
            if (option.get() == ButtonType.OK) {
                this.Computer.Delete(Computer.id);
            }
        } catch (NullPointerException var4) {
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Ошибка!");
            alert.setContentText("Вы не выбрали, чтоб удалить. Выберите!");
            alert.showAndWait();
        }

    }

    public void onSaveToFileClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Сохранить данные");
        fileChooser.setInitialDirectory(new File("."));
        File file = fileChooser.showSaveDialog(MainTable.getScene().getWindow());
        if (file != null) {
            Computer.saveToFile(file.getPath());
        }
    }

    public void onLoadToFileClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Загрузить данные");
        fileChooser.setInitialDirectory(new File("."));
        File file = fileChooser.showOpenDialog(MainTable.getScene().getWindow());
        if (file != null) {
            Computer.loadFromFile(file.getPath());
        }
    }

    public void onCloseClick()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение");
        alert.setHeaderText(String.format("Точно закрыть окно программы?"));
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get() == ButtonType.OK) {
            System.exit(1);
        }
    }

}
