ppackage sample.model;

public class Laptop  extends Computer {
    public boolean lighting;
    public int n_cor;
    public int v_memory;
    Laptop(){}
    public Laptop(String namecomputer,boolean lighting, int n_cor, int v_memory) {
        super.setnameComputer (nameComputer);
        this.lighting = lighting;
        this.n_cor = n_cor;
        this.v_memory =v_memory;
    }
    @Override
    public String getDescription() {
        boolean lighting =  this.lighting;
        int n_cor = this.n_cor;
        int v_memory= this.v_memory;
        return String.format("Ноутбук. Наличие подсветки: %s; число ядер - %s; объем памяти- %s ",lighting, n_cor,v_memory);
    }




}
