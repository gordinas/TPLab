package sample.GUI;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import sample.Main;
import sample.model.*;

import javax.swing.*;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class ComputerController implements Initializable {


    public ComputerModel ComputerObjModel;
    private Integer id = null;
    final String Computer_Laptop="Ноутбук";
    final String Computer_Smartphone="Смартфон";
    final String Computer_Tablet="Планшет";
    public ChoiceBox<Main.battery> cmbbattery;
    public ChoiceBox<String> cmbComputerObjType;
    public TextField nameComputerText;
    public CheckBox lighting_check;
    public TextField n_corText;
    public TextField v_memoryText;
    public TextField n_slotText;
    public TextField n_mpxText;
    public CheckBox checkCamera;
    public  TextField dpiText;
    public VBox LaptopPane;
    public VBox SmartphonePane;
    public VBox TabletPane;
    public ComputerModel Computer;
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        cmbComputerObjType.setItems(FXCollections.observableArrayList(
                Computer_Laptop,
                Computer_Smartphone,
                Computer_Tablet
        ));
        cmbComputerObjType.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            updatePanes((String) newValue);
        });
        cmbbattery.getItems().setAll(
                Smartphone.b.SLA,
                Smartphone.b.NiCD,
                Smartphone.b.NiMH,
                Smartphone.b.li_ion
        );
        cmbbattery.setConverter(new StringConverter< Main.battery>() {
            @Override
            public String toString(Main.battery object) {
                switch (object) {
                    case SLA: return "Свинцово-кислотный аккумулятор" ;
                    case NiCD: return "Никелево-кадмиевый аккумулятор";
                    case NiMH:  return "металло-гидридный  аккумулятор";
                    case li_ion:return "Литий-ионный аккумулятор";
                }
                return null;
            }
            @Override
            public Main.battery fromString(String string) {
                return null;
            }
        });

    }

    public void updatePanes(String value) {
        this.LaptopPane.setVisible(value.equals(Computer_Laptop));
        this.LaptopPane.setManaged(value.equals(Computer_Laptop));
        this.SmartphonePane.setVisible(value.equals(Computer_Smartphone));
        this.SmartphonePane.setManaged(value.equals(Computer_Smartphone));
        this.TabletPane.setVisible(value.equals(Computer_Tablet));
        this.TabletPane.setManaged(value.equals(Computer_Tablet));
    }

    public void setСomputer(Computer Computer) {
        this.cmbComputerObjType.setDisable(Computer != null);
        this.id = Computer != null ? Computer.id : null;
        if (Computer != null) {
            this.nameComputerText.setText(String.valueOf(Computer.getnameComputer ()));
            if (Computer instanceof Laptop) {
                this.cmbComputerObjType.setValue(Computer_Laptop);
                this.lighting_check.setText(String.valueOf(((Laptop) Computer).lighting));
                this.n_corText.setText(String.valueOf(((Laptop) Computer).n_cor));
                this.v_memoryText.setText(String.valueOf(((Laptop) Computer).v_memory));
            } else if (Computer instanceof Smartphone) {
                this.cmbComputerObjType.setValue(Computer_Smartphone);
                this.n_slotText.setText(String.valueOf(((Smartphone) Computer).n_slot));
                this.n_mpxText.setText(String.valueOf(((Smartphone) Computer).mpx));
                this.cmbbattery.setValue(((Smartphone)Computer ).b);
            } else if (Computer instanceof Tablet) {
                this.cmbComputerObjType.setValue(Computer_Tablet);
                this.checkCamera.setText(String.valueOf(((Tablet) Computer).camera));
                this.dpiText.setText(String.valueOf(((Tablet) Computer).dpi));
            }
        }
    }

    public Computer getComputer() {
        Computer result = null;
        String nameComputer = this.nameComputerText.getText();
        if((String)this.cmbComputerObjType.getValue()==  Computer_Laptop){
            boolean lighting =Boolean.parseBoolean(this.n_corText.getText());
            int n_cor=Integer.parseInt(this.n_corText.getText());
            int v_memory=Integer.parseInt(this.v_memoryText.getText());
            result = new Laptop (nameComputerText.getText(), lighting,n_cor, v_memory);
        }
        if((String)this.cmbComputerObjType.getValue()==  Computer_Smartphone){
            int n_slot = Integer.parseInt(this.n_slotText.getText());
            double mpx = Double.parseDouble (this.n_mpxText.getText());
            Main.battery b = this.cmbbattery.getValue ( );
            result = new Smartphone (nameComputerText.getText (), n_slot, mpx, b);
        }
        if((String)this.cmbComputerObjType.getValue()==  Computer_Tablet){
            boolean camera = Boolean.parseBoolean(this.checkCamera.getText());
            int dpi = Integer.parseInt (this.dpiText.getText());
            result = new Tablet (nameComputerText.getText (), camera, dpi);
        }
        return result;
    }


    public void onCancelClick(javafx.event.ActionEvent event) {
        ((Stage)((Node)event.getSource()).getScene().getWindow()).close();
    }

    public void onSaveClick(javafx.event.ActionEvent event) {
        try{
            if(this.id != null) {
                Computer Computer = getComputer ();
                Computer.id = this.id;
                this.ComputerObjModel.Edit(Computer);
            } else {
                this.ComputerObjModel.add(getComputer());
            }
            ((Stage)((Node)event.getSource()).getScene().getWindow()).close();
        }
        catch (NumberFormatException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Не все поля были заполнены. Пожалуйста, введите все данные!");
            alert.showAndWait();
        } catch (NullPointerException e){
            Alert alert = new Alert((Alert.AlertType.INFORMATION));
            alert.setTitle("Ошибка!");
            alert.setContentText("Не все поля заполнены. Повторите ввод!");
            alert.showAndWait();
        }
    }


    @FXML
    void KeyIntNumb(KeyEvent event)// ввод целых чисел
    {
        try {
            Integer.parseInt((event.getCharacter()));
        } catch (NumberFormatException e) {
            event.consume();
        }
    }

    public void KeyTemp() {
        Pattern p = Pattern.compile("(\\d+\\.?\\d*)?");
        nameComputerText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!p.matcher(newValue).matches()) nameComputerText.setText(oldValue);
        });
    }
}
